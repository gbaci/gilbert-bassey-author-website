# Handoff: Ali: Raindance release site

## Overview
These are the web pages for the launch of *Ali: Raindance* (Book One of *A Tale of Gods and Men*, by Gilbert Bassey, MoSA Publishing). Release date: **1 January 2027**. Signed preorders close **31 December 2026, 11:59 pm WAT**.

There are three pages, each with a phone and a desktop layout:
1. **Sales page:** preorder editions, the Raindance Bundle, and Founding Patrons.
2. **Free copy page:** the reader rewards campaign. Readers do a mission to get the ebook free and earn points towards signed copies and the Fan Bundle. It has a thank-you state and a post-launch state.
3. **Sample reader:** two free chapters, Chapter 3 (Ali) and Chapter 13 (the Rainmaker).

**Target codebase:** `gbaci/gilbert-bassey-author-website` (branch `main`). It's a static HTML site, and the Meta and TikTok pixels are already on its existing pages. Build these as new pages in that site using its existing conventions. Suggested routes: `/raindance`, `/raindance/free`, `/raindance/sample`.

## About the design files
The `.dc.html` files in this folder are **design references built in HTML**: prototypes that show the intended look, copy and behaviour. They are not production code. They run on a small design runtime (`support.js`) and use `{{ }}` template holes and inline styles. **Recreate them in the target site's own HTML/CSS/JS.** Don't ship these files or `support.js`.

To view them, open any `.dc.html` file in a browser from this folder; assets resolve relatively. Each file is a canvas with several labelled "turns" and options. **Only the options listed under Screens below are final.** Everything else in those files is exploration history: ignore it.

## Fidelity
**High fidelity.** The colours, type, spacing, copy and images are final. Match them closely. All copy on the pages is approved and verbatim, except the bracketed placeholders listed under Open items.

---

## Design tokens

### Colour
| Token | Value | Use |
|---|---|---|
| ground | `#0f0b08` | Page background (sales, free, sample) |
| ground-raised | `#15100b` / `#15100c` | Cards, saga band |
| ground-box | `#17110c` | Bundle / Fan Bundle card |
| ink-head | `#f1e8d7` | Headings, names |
| ink-cream | `#efe4cf` | Strong body, button outline text |
| ink-body | `#d8cdb9` | Body text |
| ink-soft | `#b9ad97` | Secondary text |
| ink-muted | `#a99c86` | Eyebrows, captions |
| ink-faint | `#8f8474` | Footer |
| gold | `oklch(0.85 0.15 85)` (≈ `#f2be48`) | Title, primary buttons, prices, accents. Use sparingly. |
| gold-line | `oklch(0.85 0.15 85 / 0.6)` | Divider rules, gold card borders |
| link | `#e9b956`, hover `#f6d58a` | Text links on dark |
| hairline | `rgba(239,228,207,0.12–0.16)` | Card borders, row rules |
| paper | `#efe6d4` | Cream panels (FAQ on the sales page, missions on the free page) |
| paper-field | `#f7f1e5` | Form fields, open mission row |
| paper-ink | `#241b12` (heads), `#2a2016`, `#3c3226`, `#4a3c2c` (body), `#6f6455` (muted) | Text on cream |
| paper-accent | `#8a5a2a` | Eyebrows and icons on cream |
| paper-rule | `rgba(36,27,18,0.14–0.25)` | Rules and borders on cream |

### Type
Only two families, both from Google Fonts: `Cinzel:wght@400;600;700` and `Spectral:ital,wght@0,300;0,400;0,500;1,300;1,400`.
- **Cinzel** is for titles, headings, eyebrows, buttons, prices and names.
- **Spectral** is for body text. The couplet and quotes are Spectral italic 300; their second line goes up to weight 400.
- **Eyebrow:** Cinzel 600, 10.5px (phone) or 12px (desktop), letter-spacing 0.3em, uppercase, ink-muted.
- **Buttons:** Cinzel 700 (primary) or 600 (outline), 13.5–14px, letter-spacing 0.12em, uppercase.
- **Body:** Spectral 16–17.5px, line-height 1.5–1.6 on phone; 17–20px, line-height 1.6 on desktop.
- **Sample reader body:** Spectral 19px, line-height 1.72.
- Use `text-wrap: balance` on headings and `text-wrap: pretty` on paragraphs.

### Shape and effects
- Radius: 2px (buttons), 3px (cards and images), 6px only on the design frames, not the page.
- Button height: 52px on phone, 54px on desktop. Primary is solid gold with `#1a120c` text. Outline is a 1px `rgba(239,228,207,0.4–0.5)` border with ink-cream text.
- Product images get `filter: drop-shadow(0 14px 18px rgba(0,0,0,0.55))`.
- Art over text uses linear gradients to the ground colour. There is never a solid bar.
- **Divider motif** (from the book cover): two 26px × 1px rules in gold-line, with a 5px gold square rotated 45° between them and 8px gaps.

### Layout
- **Phone:** designed at 390px wide. Side padding 18–26px. Vertical rhythm 40 / 56 / 64 / 72px between sections.
- **Desktop:** designed at 1280px wide. Side padding 64px. Sections 96–120px apart.
- **Breakpoint:** switch at about **900px**. Below that, use the phone layout, fluid up to its max width. At 900px and above, use the desktop layout. Centre the desktop content at max-width 1280px; art panels may bleed to the viewport edge.

---

## Screens

### 1. Sales page, phone
**File:** `Raindance Landing v3.dc.html`, option **1a** (turn 1). Turns 2 and 3 are explorations already merged into 1a.

Sections, top to bottom:
1. **Header:** sticky, 56px, transparent with no bar. ATOGAM mark `assets/brand/svg/atogam-mark-gold.svg` at 20px tall on the left. "PREORDER" outline pill on the right (gold text `#f2be48`, 1px border `rgba(242,190,72,0.6)`, Cinzel 600 12px).
2. **First screen:** 760px tall; the header overlaps it by 56px.
   - Art: `faceoff-art-1200.jpg`, cover, `object-position: 50% 20%`.
   - Gradient: `rgba(15,11,8,.5) 0%` → transparent 14% → transparent 44% → `.88` at 66% → ground at 82%.
   - Title, centred, top 150px: "ALI" (Cinzel 700 76px, gold, text-shadow `0 4px 24px rgba(0,0,0,.6)`), then "RAINDANCE" (Cinzel 600 19px, letter-spacing 0.4em, `#f6efe2`).
   - Bottom block, 26px inset, centred, 18px gap:
     - eyebrow "A TALE OF GODS AND MEN · BOOK ONE"
     - couplet "One wants nothing to do with the country. / The other wants to burn it." (20px)
     - primary button "PREORDER A SIGNED COPY", linking to `#editions`
     - outline button "CLAIM THE FREE EBOOK", linking to the free page
     - "1 January 2027"
   - **Never put type over the faces.**
3. **The story:**
   - eyebrow "THE STORY"
   - h2 "Two men. / One country." (Cinzel 600 32px)
   - Four paragraphs, 17.5px, the last in gold:
     - "The Rainmaker has declared war on Nigeria's political elite."
     - "Ali gave up his powers after devastating losses."
     - "When the Senate President hires him to rescue his kidnapped daughter, their paths collide."
     - "Neither knows it is part of a war for the soul of Nigeria five hundred years in the making."
4. **The Rainmaker band:** 640px tall, top margin 56px.
   - Art: `senate-art-1200.jpg`, `object-position: 55% 20%`. Gradient from ground at top, transparent 14–42%, to ground at bottom.
   - Bottom-left text: eyebrow "THE RAINMAKER" in gold, then the quote "“Citizens of the hopeless Republic of Nigeria… / Today, I bring you fire.”" (italic 300, 25px, second line 400). **No link here.**
5. **Chapter tiles:** a 2-column grid with a 10px gap. Each tile is 300px tall with 3px radius, and the whole tile is a link.
   - **Ali tile:** `portraits/ali.jpg`, name "Ali", role "The Man Who Feels Everyone's Pain", link text "READ CHAPTER 3 →", links to `sample#ali`.
   - **Rainmaker tile:** `portraits/rainmaker-hands.jpg`, name "The Rainmaker", role "The Revolutionary", link text "READ CHAPTER 13 →", links to `sample#rainmaker`.
   - **Eye level must match across the two tiles** (eyes about 40% down the tile). Prototype values at 172px tile width:
     - Ali: image 240px wide, top −24px
     - Rainmaker: image 300px wide, top −2px
     - Both: centred with `translateX(-51%)`
     - Scale these in proportion to the tile width.
   - Overlay gradient: transparent at 40% → `rgba(15,11,8,.95)`.
   - Caption under the grid: "Two free chapters, one for each of them."
6. **Caught in the storm (cast spotlight):** eyebrow centred.
   - One large portrait, 440px tall, with name (Cinzel 700 26px), role (italic, gold) and line overlaid at the bottom.
   - Below it, 4 square thumbnails, each with a 2px border: gold when selected, transparent otherwise.
   - Tapping a thumbnail cross-fades the large portrait (opacity, 0.35s) and swaps the text.
   - Default selection: Okoro.
   - Order and copy:
     - **Okoro**: The Last Idealist. "Ali's grandfather, a journalist who still believes the truth can move a country."
     - **Abubakar**: The General. "Retired general, Senate President, presidential candidate. His daughter calls his fortune blood money."
     - **Farida**: The Defiant Daughter. "The Senate President's daughter, taken in the Rainmaker's latest act."
     - **Daniel**: The Protégé. "Fifteen, sweet-toothed and fiercely loyal. The Rainmaker saved him, and Daniel would do anything for him."
7. **Choose your edition (`#editions`):**
   - Eyebrow, then "Preorder by 31 December and it's signed."
   - Three columns, each: product image, name, price in gold, action link:
     - Ebook ₦5,000 "BUY →"
     - Paperback ₦10,000 "PREORDER →"
     - Hardcover ₦25,000 "PREORDER →"
   - **The Raindance Bundle card:** gold-line border, ground-box background.
     - `p-box.png` on a radial glow, with a "LIMITED TO 50" gold tag at top left.
     - Title "The Raindance Bundle", price ₦50,000.
     - 2×2 contents grid: **Rainmaker tee**, **Character cards**, **The Nigerian Sentinel front page**, **Series bookmark**.
     - Line: "With a signed, hand-numbered hardcover. Six character cards open the world."
     - Primary button "PREORDER THE BUNDLE", then "Numbers go in order of payment."
   - Under the card: "Prices exclude delivery. Delivery and refunds", where "Delivery and refunds" links to `#faq`.
8. **Saga band:** background `#15100c` with hairlines top and bottom.
   - Eyebrow "A TALE OF GODS AND MEN", h2 "Six books. / One war."
   - Six covers in 2:3 ratio: Book One is the real cover; Book II has a solid gold outline; III–VI are dashed.
   - Labels under the covers: "Ali: Raindance", "Ali: Revolution", "The story continues".
   - "Book Two is already written." in gold, then "The story is planned to its final page."
9. **Founding Patrons (`#patrons`, a shareable anchor):**
   - Eyebrow, h2 "Help birth the next book."
   - Gilbert's note, two paragraphs, signed "— Gilbert". The copy is in the file; it says "twenty Founding Patron places".
   - Offer card:
     - Places line and ₦200,000.
     - **20 seats** in a 10-column grid (2 rows). A taken seat is solid gold; an open seat has a gold-line outline.
     - Four tiles:
       - BOOK ONE "Raindance Bundle, numbered F01–F20"
       - BOOK TWO "Book Two bundle, same number"
       - YOUR CARD "Signed patron card with your name"
       - THE SAGA "Your name in Book Two"
     - Primary button "BECOME A FOUNDING PATRON".
     - Terms accordion with 5 items. The copy is in the file.
   - Places line text: "TWENTY PLACES · F01–F20" when none are taken, otherwise "N OF 20 PLACES LEFT". `placesTaken` should come from a config value.
10. **Author:** photo `images/gilbert-author-photo2.jpg` (96×120, `grayscale(0.2)`), eyebrow, name, bio, and the "@onegillianbaci" link.
11. **FAQ (`#faq`):** cream panel, accordion with 7 items. The copy is in the file. Only one item is open at a time, and the +/− sign swaps.
12. **Closing image:** `assets/plaza-art.jpg` at full width with natural height (603px at 390). Gradient: ground → transparent 12% → transparent 82% → ground. The two buttons sit below it. **No tagline or title here.**
13. **Footer:** © line plus the links Contact, Privacy, Terms and refunds, Instagram.

### 2. Sales page, desktop
**File:** `Raindance Desktop.dc.html`, option **2a** (turn 2, full page). Turn 1 has the three directions; 1b won.

This is the split editorial layout:
- **First screen:** 820px tall, grid `560px | 1fr`.
  - Left column: ATOGAM mark at top. Then, vertically centred: the eyebrow; "ALI" (112px gold); the divider; "RAINDANCE" (26px, 0.4em); the couplet (23px); both buttons stacked at 340px wide; the date.
  - Right column: face-off art as a tall panel, cover, `50% 30%`, with a left-edge gradient from ground to transparent at 22%.
  - Top-right nav over the art: THE STORY · EDITIONS · PATRONS. Cinzel 600 12px, gold `#f2be48`, with `text-shadow: 0 1px 10px rgba(0,0,0,.85), 0 0 2px rgba(0,0,0,.6)`.
- **Story:** grid `1fr | 620px`. The text is on the left; the Senate art panel on the right is 700px tall, with the eyebrow and quote overlaid at the bottom.
- **Chapters and cast:** grid `620px | 1fr`.
  - Left: the two chapter tiles, each 400px tall.
    - Ali: image 300px wide, top −30px.
    - Rainmaker: image 400px wide, top −12px.
  - Right: eyebrow plus a 2×2 compact cast list. Each entry has an 88×112 portrait beside the name, role and line. **No spotlight interaction on desktop.**
- **Editions:** grid `300px | 1fr`.
  - Left: eyebrow plus h2 "Preorder by 31 December and it's signed."
  - Right: three edition cards, then the bundle card at full width. Contents in 4 columns.
- **Saga:** grid `420px | 1fr`.
- **Patrons:** grid `1fr | 560px`, note on the left and offer card on the right.
- **Author:** 160×200 photo with the bio.
- **FAQ:** cream band, grid `300px | 760px`, with the heading "Before you order".
- **Closing:** grid `720px | 1fr`, 760px tall. The plaza art is on the left (`50% 62%`, gradient from the right edge). On the right, the two buttons stacked at 340px wide, vertically centred.
- **Footer:** single row.

### 3. Free copy page, phone
**File:** `Raindance Free Copy.dc.html`, option **4a** (turn 4) for the page, and turn 6 for the states.

Sections, top to bottom:
1. **Header:** ATOGAM mark on the left, "BUY THE BOOK →" on the right, linking to the sales page.
2. **Hero:** centred.
   - Cover image, 168px wide.
   - Eyebrow "THE RAINDANCE READER REWARDS".
   - h1 "Get the ebook free. Earn a signed copy."
   - Line: "Do one thing to share it before launch. Do more to collect more."
   - Primary button "CLAIM YOUR FREE EBOOK", which scrolls to the form.
   - "Out 1 January 2027".
3. **What you can win:**
   - Free ebook row (gold border): "On release day", **1 TASK**.
   - Divider "THEN COLLECT POINTS".
   - Three tiles:
     - 5 PTS "Read it early", sub-line "Emailed on approval"
     - 10 PTS "Signed paperback"
     - 15 PTS "Signed hardcover"
   - **The Rainmaker Fan Bundle card:** "30 POINTS · TOP PRIZE" tag, box image, then an INSIDE shelf of 5 items: Signed paperback, Rainmaker tee, Character cards, Sentinel front page, Bookmark.
     - The items are top-aligned and every image is 82px tall.
   - Caption: "Every reward is open to everyone who reaches it."
4. **Steps:** 1 Share / Pick a mission · 2 Submit / Send a screenshot or link · 3 Earn / Get approved by email.
5. **Choose your mission:** cream panel, "Any one gets you the ebook."
   - An accordion checklist of 4 rows. Each row has a round icon, title and reward chip. Opening a row shows the instructions, an action button and "DONE IT? SEND PROOF ↓".
   - **Share a post** (EBOOK): "Put the cover, a poster or the trailer on your WhatsApp status, Instagram, X or TikTok." Action: GET THE ASSETS.
   - **Add it to your reading list** (EBOOK): "Mark Ali: Raindance as Want to Read on Goodreads or StoryGraph." Action: OPEN GOODREADS.
   - **Make a video** (+3 PTS): the ideas list and the rule that every video must send people to this page. Up to 3 videos. Action: GET THE POSTERS.
   - **Make the Rainmaker's mask** (+5 PTS): "Make the mask, take a picture with it and post it with **#TheRainmakerRises**. The best ones are featured here." Action: GET THE MASK GUIDE.
6. **Claim form:** "LAST STEP · Claim your ebook".
   - Fields: Name, Email, Mission (pre-filled from the last opened mission), proof upload or link, Referred by (optional).
   - Pre-fill "Referred by" from a `?ref=` URL parameter.
   - Button "CLAIM MY FREE EBOOK".
   - Below it: "Checked by hand within two days. Your ebook link arrives in the approval email. Privacy notice". **No WhatsApp number field.**
7. **Questions:** accordion with 4 items. The first contains the points table:
   - A friend claims through your link: 1 point
   - A video (up to 3): 3 points each
   - A photo with your Rainmaker's mask: 5 points
   - A review after you've read it: 5 points
8. **Footer line:** "Want it signed now? Preorder by 31 December →"
9. **Sticky claim bar:** "CLAIM YOUR FREE EBOOK ↓". It shows only after the hero button has scrolled out of view, and hides once the form is in view.

**Thank-you state** (option **6a**): this replaces the page after a successful submit.
- Cover at 132px.
- Eyebrow "CLAIM RECEIVED" in gold.
- h1 "Thank you."
- "Your mission is in. Once approved, your free ebook will arrive on 1 January 2027."
- "If you want to read it earlier than that, do more missions to get 5 points and unlock the early reader reward."
- The divider motif.
- **KEEP GOING strip:** a 2×2 grid of reward tiles: 5 Read it early (gold border), 10 Signed paperback, 15 Signed hardcover, 30 Rainmaker Fan Bundle.
- Three "what happens next" steps:
  - We check it by hand / Within two days.
  - You get an approval email / It carries your ebook link and your personal referral link.
  - Share your link / Every friend who claims through it earns you a point.
- Buttons: "DO ANOTHER MISSION" (primary, returns to the missions) and "READ TWO FREE CHAPTERS" (outline, links to the sample).
- Note: "Didn't get an email within two days? Check spam, then contact us."

**After-launch state** (option **6b**): see Launch phase below.

### 4. Free copy page, desktop
**File:** `Raindance Free Copy Desktop.dc.html`, option **1a** for the page, with states **2a** (thank you) and **2b** (after launch).
- **Hero:** grid `1fr | 520px`. Text on the left (h1 at 52px). The cover (300px) on a radial glow on the right.
- **Rewards:**
  - Heading row: grid `300px | 1fr`, with the h2 "One task for the ebook. Points for the rest."
  - 4-column reward row: Free ebook (1 task), then 5, 10 and 15 points.
  - Fan Bundle as a wide split card: box on the left; INSIDE with 5 items in a row on the right.
- **Steps:** in a row of 3.
- **Missions and form:** cream band, grid `1fr | 460px`. The mission accordion is on the left and the form card (`#claim`) on the right, so the form is always visible while a mission is open.
- **Questions:** grid `300px | 760px`.
- **Thank-you state:** two columns (the message on the left; what happens next plus the buttons in a card on the right), with the KEEP GOING strip as a 4-across row below.

### 5. Sample reader
**File:** `Raindance Sample.dc.html`. It's fluid; the same layout serves phone and desktop.
- **Sticky header:** `rgba(15,11,8,.94)` with a hairline bottom border, max-width 680px. ATOGAM mark on the left, linking to the sales page. A two-tab toggle on the right: "ALI" / "THE RAINMAKER". The active tab is solid gold.
- **Reading column:** max-width 640px, padding 56px 24px 96px. Eyebrow "ALI: RAINDANCE · FREE SAMPLE".
- **Chapter opener:** a full-bleed portrait (4:5 ratio, max 600px tall, bleeding 24px past the column on each side, gradient to ground at the bottom). Then "CHAPTER THREE" / "A Man Apart" or "CHAPTER THIRTEEN" / "The Rainmaker".
  - Ch 3 uses `ali.jpg` (`50% 35%`); Ch 13 uses `rainmaker-hands.jpg` (`50% 30%`).
  - The prototype has a fallback to small symbol icons (`opener` prop). Use the portraits.
- **Body:** Spectral 19px, line-height 1.72, paragraph gap 1.1em. The chapter text is in the file.
- **Chapter 3 ending:** "TEN CHAPTERS LATER" / "The country is about to meet him." plus a button that switches to Chapter 13.
- **Routing:** `#ali` and `#rainmaker` select the chapter on load. Switching tabs updates the hash (`history.replaceState`) and scrolls to the top.

---

## Launch phase (before and after 1 January 2027)
Drive this from one date check: `now >= 2027-01-01T00:00:00+01:00` (WAT). Also allow an override with `?phase=before|after` for QA.

| Element | Before launch | After launch |
|---|---|---|
| Sales page first-screen buttons | PREORDER A SIGNED COPY · CLAIM THE FREE EBOOK | BUY THE BOOK · GET YOUR FREE COPY |
| Sales page date line | 1 January 2027 | Out now |
| Edition actions | Ebook BUY → · Paperback/Hardcover PREORDER → | All BUY → |
| "Preorder by 31 December and it's signed." | shown | hidden |
| Bundle button | PREORDER THE BUNDLE | BUY THE BUNDLE (or SOLD OUT when 50 are gone) |
| Closing buttons | as first screen | as first screen |
| Free page eyebrow | THE RAINDANCE READER REWARDS | OUT NOW (gold) |
| Free page line | "Do one thing to share it before launch. Do more to collect more." | "Do one thing to share it. Your ebook arrives as soon as you're approved." |
| Free page date line | Out 1 January 2027 | removed |
| Free ebook sub-line | On release day | Emailed on approval |
| "Read it early" (5 pts) reward | shown | removed (it ends on release day) |
| Free page footer | "Want it signed now? Preorder by 31 December →" | "Want a copy now? Buy the book →" |
| Thank-you copy | "…will arrive on 1 January 2027." + the early-reader line | "…will arrive in your approval email." with the early-reader line removed; the KEEP GOING strip drops the 5-pt tile |

Also, between 31 Dec 11:59 pm WAT and launch, the signed-copy promise ends: hide the "signed" wording.

Points already earned carry over. Every reward is uncapped.

## Interactions summary
- **Accordions** (sales FAQ, patron terms, free FAQ, missions): only one item open per group. The +/− sign swaps. No animation is required; if you add one, use a 150–200ms height or opacity ease.
- **Cast spotlight** (phone): selected index, opacity cross-fade 0.35s.
- **Mission selection:** opening a mission sets the form's Mission field.
- **Free page scroll targets:** the hero CTA, "DONE IT? SEND PROOF ↓" and the sticky bar all smooth-scroll to the form.
- **Form:** Name and Email are required, with email format validated. Proof is required: a file (image) or a URL. Referred by is optional. On submit, show the thank-you state; don't navigate to a new URL, or use `#thanks`. On error, show an inline message under the button.
- **Anchors:** `#editions`, `#patrons`, `#faq` on the sales page; `#ali`, `#rainmaker` on the sample page.

## Analytics
Meta and TikTok pixels already exist in the repo. Fire:
- PageView on all three pages.
- `ViewContent` on the sales page.
- `InitiateCheckout` on any preorder, buy, bundle or patron button, with the edition name as a parameter.
- `Lead` on a successful free-claim submit.
- A custom `SampleRead` event when the end of a chapter is reached.

## Backend needs (not designed; implementer's choice)
- **Claim submissions:** name, email, mission, proof file or link, ref, timestamp. They are reviewed by hand. Approval sends an email containing the ebook link (after launch) or a confirmation (before launch) and the person's **personal referral link** (`/raindance/free?ref=CODE`).
- **Points ledger:** keyed by email, updated from approvals, one point per approved referral.
- **Checkout:** for the editions, the bundle (50 numbered, in payment order) and the patrons (20 places, F01–F20). `placesTaken` and the bundle count should read from the same source.

## Open items (bracketed placeholders in the files)
- Patron terms: [Book Two editing] · [Book Two cover art] · [Book Two bundle production]; [shipping window]; the Book Two delay fallback; delivery fee; refund policy.
- FAQ: delivery within Nigeria [₦X], international [policy], [shipping window], refund [policy].
- Contact, Privacy and Terms page URLs; the Instagram URL.
- Mission asset links: GET THE ASSETS, GET THE POSTERS, GET THE MASK GUIDE, and the Goodreads book URL.
- The mask-gallery feature ("The best ones are featured here"): not designed yet.

## Assets
All of these are in `assets/` and `images/`, at the paths used by the design files.
- **Art:**
  - `web/faceoff-art-1200.jpg`: front-cover art, no type.
  - `web/senate-art-1200.jpg`: back-cover art.
  - `plaza-art.jpg`: the burning National Assembly dome.
  - `web/cover-front-800.jpg`: the final cover.
- **Portraits** (`web/portraits/`): `ali`, `rainmaker-hands`, `okoro`, `abubakar`, `farida`, `daniel`. All 720×1080 JPEG, graded to match the cover art. Gilbert's own character renditions.
- **Products** (`web/`): `p-ebook`, `p-paperback`, `p-hardcover`, `p-box`, `p-envelope-cards`, `p-paper-folded`, `p-bookmark`, `p-shirt-mask` (all PNG; product renders, plus the tee cropped from Gilbert's mockup).
- **Brand:** `brand/svg/atogam-mark-gold.svg`. Fallback chapter icons: `cards/ali-heart-gold.png`, `mask-gold.png`.
- **Author:** `images/gilbert-author-photo2.jpg`.
- **Fonts:** Google Fonts (Cinzel, Spectral). Oswald appears only in the design canvas labels; don't use it on the site.

**Don't use** the old ebook export in the main project's `exports/`; it has the wrong cover. Character names Lighthouse and Zaka must never appear on any page (spoiler).

## Files in this folder
| File | Final option(s) |
|---|---|
| `Raindance Landing v3.dc.html` | Sales, phone: **1a** |
| `Raindance Desktop.dc.html` | Sales, desktop: **2a** |
| `Raindance Free Copy.dc.html` | Free, phone: **4a** page, **6a** thank you, **6b** after launch |
| `Raindance Free Copy Desktop.dc.html` | Free, desktop: **1a** page, **2a** thank you, **2b** after launch |
| `Raindance Sample.dc.html` | Sample reader (whole file) |
| `support.js`, `image-slot.js` | Prototype runtime only; don't ship |
